# How to verify this bundle

This bundle contains signed, hash-chained records of actions taken by an AI agent.
You can check it yourself, offline, without access to the vendor's systems:

    pipx run gleipnir-verify bundle.zip --expect-key k_ed25519_93ae18e62223e3c5 --require-anchor rekor --require-anchor rfc3161 --max-anchor-delay 86400 --require-full

or, with Node.js:

    npx -p @getgleipnir/verify gleipnir-verify bundle.zip --expect-key k_ed25519_93ae18e62223e3c5 --require-anchor rekor --require-anchor rfc3161 --max-anchor-delay 86400 --require-full

What the options do:

    --expect-key KEY        fail unless the chain is signed with this key
                            (compare with the key id the vendor publishes)
    --require-anchor rekor  fail unless every segment is anchored in the public
                            Sigstore Rekor log (so receipts cannot be silently removed)
    --require-anchor rfc3161
                            fail unless every segment carries a trusted RFC 3161 timestamp
    --max-anchor-delay SEC  fail if a segment was timestamped long after it closed
                            (catches history that was rebuilt and re-anchored later)
    --require-full          fail unless the bundle starts at the beginning of the chain
    --known-head SEQ:HASH   fail unless the head you saw in an earlier bundle is still
                            there, unchanged (detects truncation and rewritten history)
    --expect-until TIME     fail if the records stop earlier than this
    --json                  machine-readable result

A VALID result means: no record was edited, removed, reordered or inserted after it was
written, every segment's Merkle root matches, and anchor receipts check out. It does not
mean the agent's decisions were correct, and it cannot show actions the vendor never
recorded: reconcile the external object ids in the records with your own systems.
